package com.example.appringtones;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    Button play1, play, play2, play3, play4, downland1, downland, downland2, downland3, downland4,
    share1, share, share2, share3, share4, blue1, blue2, blue3, blue4,blue5;

    MediaPlayer mp1, mp2, mp3, mp4, mp5;

    String url1, url2, url3, url4, url5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Botones de play
        play1 = (Button) findViewById(R.id.play1);
        play = (Button) findViewById(R.id.play);
        play2 = (Button) findViewById(R.id.play2);
        play3 = (Button) findViewById(R.id.play3);
        play4 = (Button) findViewById(R.id.play4);

        //Botones de descarga
        downland1 = (Button) findViewById(R.id.downland1);
        downland = (Button) findViewById(R.id.downland);
        downland2 = (Button) findViewById(R.id.downland2);
        downland3 = (Button) findViewById(R.id.downland3);
        downland4 = (Button) findViewById(R.id.downland4);

        //Botones de compartir
        share1 = (Button) findViewById(R.id.share1);
        share = (Button) findViewById(R.id.share);
        share2 = (Button) findViewById(R.id.share2);
        share3 = (Button) findViewById(R.id.share3);
        share4 = (Button) findViewById(R.id.share4);

        //Botones de bluetooh
        blue1 = (Button) findViewById(R.id.blue1);
        blue2 = (Button) findViewById(R.id.blue2);
        blue3 = (Button) findViewById(R.id.blue3);
        blue4 = (Button) findViewById(R.id.blue4);
        blue5 = (Button) findViewById(R.id.blue5);

        //media players
        mp1=MediaPlayer.create(this, R.raw.homero);
        mp2 = MediaPlayer.create(this, R.raw.mariob);
        mp3 = MediaPlayer.create(this, R.raw.mariom);
        mp4 = MediaPlayer.create(this, R.raw.mariot);
        mp5 = MediaPlayer.create(this, R.raw.mariov);

        //URLS
        url1 = "http://www.sonidosmp3gratis.com/download.php?id=16576&sonido=homero%20mensaje";
        url2 = "http://www.sonidosmp3gratis.com/download.php?id=16534&sonido=super%20mario%20bros";
        url3 = "http://www.sonidosmp3gratis.com/download.php?id=15465&sonido=mario%20bros%20game%20over";
        url4 = "http://www.sonidosmp3gratis.com/download.php?id=15284&sonido=mario%20bros%20tuberia";
        url5 = "http://www.sonidosmp3gratis.com/download.php?id=15283&sonido=mario%20bros%20vida";

        // Reproduce audio 1
        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp1.isPlaying()) {
                    mp1.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp1.start();
                    Toast.makeText(MainActivity.this, "play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Reproduce audio 2
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp2.isPlaying()) {
                    mp2.pause();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                } else {
                    mp2.start();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Repruduce audio3
        play2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp3.isPlaying()) {
                    mp3.pause();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                } else {
                    mp3.start();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Reproduce audio 4
        play3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp4.isPlaying()) {
                    mp4.pause();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                } else {
                    mp4.start();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Reproduce audio 5
        play4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp5.isPlaying()) {
                    mp5.pause();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                } else {
                    mp5.start();
                    Toast.makeText(MainActivity.this, "pause", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Ejecuta boton de descarga 1
        downland1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url1);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        //Ejecuta boton de descarga 2
        downland.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url2);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        //ejecuta boton de descarga 3
        downland2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url3);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        //Ejecuta boton de descarga 4
        downland3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url4);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        //Ejecuta boton de descarga 5
        downland4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url5);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        //Comparte audio 1
        share1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        //comparte audio 2
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        //Comparte audio 3
        share2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        //comparte audio 4
        share3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        //comparte audio 5
        share4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });



    }
}